package com.example.todolist;

import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.runner.RunWith;
import androidx.test.filters.LargeTest;
import androidx.test.internal.runner.junit4.AndroidJUnit4ClassRunner;


@RunWith(AndroidJUnit4ClassRunner.class)
@LargeTest
public class AddListTest {
    private AddList addList;
    @Test
    public void testDodawaniaDoBazy() {
        addList.textTytul.setText("Tytuł test");
        addList.textOpis.setText("Opis test");
        addList.textData.setText("Data test");

        assertTrue(addList.insertData("Tytuł test", "Opis test", "Data test"));
    }

    @Test
    public void testDodawaniaDoBazyBrakDanych() {
        assertFalse(addList.insertData("", "", ""));
    }
}